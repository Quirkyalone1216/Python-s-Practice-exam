#ch7-test5
n = int(input("n:"))
m = int(input("m:"))
if m>n:
    total = sum(range(n,m+1))
    print("Result: %d" % total)
elif n>m:
    print("n>m,Error")
