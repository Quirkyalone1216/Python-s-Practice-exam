#ch7-test2
players = [['James',202],['Curry',193],['Durant',205],['Joradn',199],['David',211]]
for player in players:
    if player[1] <= 200:
        continue
    print(player)