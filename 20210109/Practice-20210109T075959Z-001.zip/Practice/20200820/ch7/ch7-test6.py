#ch7-test6
# 華氏= 攝氏*(9/5)+32. 攝氏= (華氏-32)*5/9
fahrenheit = [32,77,104]
celsius = [((x-32)*5/9)for x in fahrenheit]
print(celsius)