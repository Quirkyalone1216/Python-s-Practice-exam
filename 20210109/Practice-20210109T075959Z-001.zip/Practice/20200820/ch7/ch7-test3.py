#ch7-test3
money = int(input("Principal:"))
rate = float(input("Annual interest rate:"))
deposit = int(input("Deposit years:"))
for i in range(deposit):
    money *= (1+rate)
    print("第 %d 年本金和 : %d" %((i+1),int(money)))