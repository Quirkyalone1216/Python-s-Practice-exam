#ch7-test7
xlist = [n for n in range(2,20+1,2)]
print(xlist)