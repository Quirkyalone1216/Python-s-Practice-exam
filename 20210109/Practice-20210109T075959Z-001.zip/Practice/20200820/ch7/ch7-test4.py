#ch7-test4
weight = 50
years = 5
auunal_increase = 1.2
for summation in range(0,years):
    sum = years * auunal_increase
weight += sum
print(weight)
