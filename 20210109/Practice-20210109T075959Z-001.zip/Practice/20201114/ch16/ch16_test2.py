#ch16_test2
#Reference ch16_2.py
import os
alllist = os.walk(os.getcwd())

def get_objtree_file():
    """讀取當前路徑和data子目錄內的檔案路徑"""
    fileNames = ''
    dir_path = ''
    for dir_path, sub_dirNames, fileNames in alllist:
        if sub_dirNames == ['data']:
            parent_path =  dir_path
            if sub_dirNames == [None] and dir_path == parent_path:
                break
    return fileNames,dir_path

def batch_readfiles():
    """批量讀取目標目錄檔案,回傳檔案內字元長度"""
    files,dirName = get_objtree_file()
    files_Namearr = []
    obj_fileName = ''
    for file in files:
        obj_fileName = os.path.join(dirName,file)
        files_Namearr.append(read_file(obj_fileName))
    files_arrLen = len(files_Namearr)
    if files_arrLen > 1:
        return files_Namearr
    elif files_arrLen <= 1:
        return obj_fileName

def read_file(fn):
    """讀取檔案,回傳檔案內容"""
    try:
        with open(fn,mode='r') as obj_file:
            data = obj_file.read()
    except FileNotFoundError:
        return ("找不到 %s 檔案" %fn)
    else:
        return data

def search_str(data):
    """搜尋字串中的關鍵字"""
    count = 0
    search = str(input('請輸入搜尋字串:'))
    count = data.count(search)
    print('所搜尋字串 %s 出現過 %d 次' % (search,count))

def process_file():
    while 1:
        files_Name = batch_readfiles()
        data = read_file(files_Name)
        search_str(data)
        continues = input('是否繼續搜尋,輸入Y或y則程式繼續=')
        if continues not in ('y' or 'Y'):
            break
if __name__ == '__main__':
    process_file()
