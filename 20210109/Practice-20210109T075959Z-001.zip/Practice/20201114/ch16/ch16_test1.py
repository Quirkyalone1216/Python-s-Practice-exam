#ch16_test1
import re

msg1 = 'Please call my secretary using 0930-919-919 or 0952-001-001'
msg2 = '請明天17:30和我一起參加明志科大教師節晚餐'
msg3 = '133-1234-1234'
msgs = [msg1,msg2,msg3]

def parseString(string):
    """判斷字串是否含有中國手機號碼"""
    pattern = r'\d{3}-\d{4}-\d{4}'
    phoneNum = re.search(pattern,string)
    bool1 = 0
    if phoneNum != None:
        bool1 = True
    else:
        bool1 = False
    bool1 = str(bool1)
    str1 = string + ':是中國手機號碼' + bool1
    print('%10s' % str1)       # 串列方式顯示電話號碼

if __name__ == '__main__':
    for msg in msgs:
        parseString(msg)