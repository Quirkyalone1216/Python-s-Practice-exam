#ch15_test6
#Re-Design ch15_5.py
import os
alllist = os.walk(os.getcwd())

def get_objtree_file():
    """讀取當前路徑和data子目錄內的檔案路徑"""
    fileNames = ''
    dir_path = ''
    for dir_path, sub_dirNames, fileNames in alllist:
        if sub_dirNames == ['data']:
            parent_path =  dir_path
            if sub_dirNames == [None] and dir_path == parent_path:
                break
    return fileNames,dir_path

def read_file(fn):
    """讀取檔案,回傳檔案長度"""
    try:
        with open(fn,mode='r') as obj_file:
            data = obj_file.read()
    except FileNotFoundError:
        print("找不到 %s 檔案" %fn)
    else:
        length = len(data)
        return length

def word_length(obj):
    """"檢查檔案內字元長度是在10-35個字"""
    if obj < 10:
        raise Exception('檔案長度不足')
    elif obj > 35:
        raise Exception('檔案長度太長')
    else:
        return ('檔案長度正確')

def batch_readfiles():
    """批量讀取目標目錄檔案,回傳檔案內字元長度"""
    files,dirName = get_objtree_file()
    length_value = []
    files_Namearr = []
    for file in files:
        obj_fileName = os.path.join(dirName,file)
        length = read_file(obj_fileName)
        files_Namearr.append(file)
        length_value.append(length)
    return length_value,files_Namearr

if __name__ == '__main__':
    length_value,file_Namearr = batch_readfiles()
    list_len1 = len(file_Namearr)
    check_result = []
    Files_result = []
    for check in length_value:
        try:
            check_result.append(word_length(check))
        except Exception as err:
            check_result.append('檔案長度檢查異常發生:' + str(err))
    for i in range(list_len1):
        str1 = str(file_Namearr[i]) + '文章的字數是' + str(length_value[i])
        Files_result.append(str1)
    for j in range(list_len1):
        print(Files_result[j])
        print(check_result[j])