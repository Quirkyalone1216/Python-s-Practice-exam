#ch13_test9
import keyword

n = input('Input String:')
if not n:
    print('輸入錯誤')
    n = input('Input String:')
n = str(n)
keyword = keyword.kwlist

for i in range(len(keyword)):
    if keyword[i] == n:
        print(n, '是關鍵字')
        break
    elif keyword[i] != n:
        if i == len(keyword):
            print(n, '不是關鍵字')
            break
        else:
            print(n, '不是關鍵字')
            break
