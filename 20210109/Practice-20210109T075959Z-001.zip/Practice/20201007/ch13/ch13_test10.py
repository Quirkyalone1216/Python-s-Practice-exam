#ch13_test10
import calendar,time

def input_value_year():
    year = 0
    year = int(year)
    def input_year():
        year = input('請輸入年份:')
        if not year:
            print('年份輸出錯誤')
            year = input('請輸入年份:')
        year = int(year)
        return year
    def judgment_year():
        local_time = time.localtime()
        local_time = list(local_time)
        if year > local_time[0] + 100:
            print('年份輸入過大')
        else:
            return False
    year = input_year()
    if judgment_year() != False:
        input_value_year()
    else:
        return year
def input_value_month():
    month = input('請輸入月份:')
    if not month:
        print('月份輸出錯誤')
        month = input('請輸入月份:')
    month = int(month)

    def judgment_month():
        if month > 12:
            print('月份輸入過大')
        else:
            return False
    if judgment_month() != False:
        input_value_month()
    else:
        return month
def input_value():
    year = 0
    month = 0
    year = int(year)
    month = int(month)
    year = input_value_year()
    month = input_value_month()
    return year,month
def main():
    year = 0
    month = 0
    year = int(year)
    month = int(month)
    year,month = input_value()
    print(calendar.month(year,month))
main()