#ch8-test2
members = ('John','Peter','Curry','Mike','Kevin')
for member in members:
    print(member)
members[0] = 'Johnnason'
print(members[0])