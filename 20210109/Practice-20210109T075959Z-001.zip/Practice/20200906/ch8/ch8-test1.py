#ch8-test1
members = ('John','Peter','Curry','Mike','Kevin')
for member in members:
    print(member)