#ch8-test3
members = ('John','Peter','Curry','Mike','Kevin')
print("Original")
for member in members:
    print(member)
members_added = ('Mary','Tom','Carlo')
members+=members_added
print("New")
for member in members:
    print(member)