#ch6-test4
city = ['Baishan','Taipei','Xian','Tokyo','London']
print(city,"original city list")
city = ['Baishan','Taipei','Tokyo']
print(city)
city.insert(2,'Xian')
print(city,"insert element to city list place on the middle")
city.insert(4,'London')
print(city,"insert element to city list place on the end")
city.remove('Tokyo')
print(city,"'Tokyo' has been deleted element in city list")
