#ch6-test6
sc = [['洪錦魁',]]