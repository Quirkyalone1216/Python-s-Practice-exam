from PIL import Image
from PIL import ImageFilter
import os
import send2trash
import glob


def get_current_tree():
    """讀取當前檔案路徑和Resoures資料夾內的檔案名稱"""
    path = os.walk(os.getcwd())
    for dir_path, sub_dirNames, fileNames in path:
        obj_dir_path = os.path.join(dir_path, 'Resoures')
        files = os.listdir(obj_dir_path)
        return obj_dir_path, files


def check_file_extension(datas):
    """確認檔案副檔名"""
    result_img = []
    for data in datas:
        if data.lower().endswith(('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
            if data is not None:
                result_img.append(data)
    return result_img


def checkDir_exist(specific_path):
    Dir_exist = os.path.exists(specific_path)
    if Dir_exist is False:
        os.mkdir(specific_path)
    elif Dir_exist is True:
        list_file = []
        list_file1 = []
        for file1 in os.listdir(specific_path):
            list_file1.append(file1)
            for file in glob.glob('fig17_4.*'):
                list_file.append(file)
        if len(list_file) > 0:
            for file_exist in list_file:
                send2trash.send2trash(file_exist)
        elif len(list_file) == 0:
            return 1


def file_process():
    obj_dir_path, files = get_current_tree()
    outdir_path = os.path.join(obj_dir_path, 'Output')
    while 1:
        flag = checkDir_exist(outdir_path)
        if flag is 1:
            break
    return obj_dir_path, outdir_path


def check_fileExtension(datas):
    """確認檔案副檔名"""
    result_img = []
    for data in datas:
        if data.lower().endswith(('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
            if data is not None:
                result_img.append(data)
    return result_img


class ImgFilter:
    def __init__(self, FilterMode, file, OutDirPath):
        self.mode = FilterMode
        self.file = file
        self.OutDirPath = OutDirPath

    def SelectMode(self):
        def ImgPath(mode, OutDirPath):
            name = 'fig17_4_' + str(mode) + '.jpg'
            Dirpath = os.path.join(OutDirPath, name)
            return Dirpath

        if self.mode == "BLUR":
            Img = self.file.filter(ImageFilter.BLUR)
            path = ImgPath(self.mode, self.OutDirPath)
            Img.save(path)
        elif self.mode == "CONTOUR":
            Img = self.file.filter(ImageFilter.CONTOUR)
            path = ImgPath(self.mode, self.OutDirPath)
            Img.save(path)
        elif self.mode == "DETAIL":
            Img = self.file.filter(ImageFilter.DETAIL)
            path = ImgPath(self.mode, self.OutDirPath)
            Img.save(path)
        elif self.mode == "EDGE_ENHANCE":
            Img = self.file.filter(ImageFilter.EDGE_ENHANCE)
            path = ImgPath(self.mode, self.OutDirPath)
            Img.save(path)
        elif self.mode == "EDGE_ENHANCE_MORE":
            Img = self.file.filter(ImageFilter.EDGE_ENHANCE_MORE)
            path = ImgPath(self.mode, self.OutDirPath)
            Img.save(path)
        elif self.mode == "EMBOSS":
            Img = self.file.filter(ImageFilter.EMBOSS)
            path = ImgPath(self.mode, self.OutDirPath)
            Img.save(path)
        elif self.mode == "FIND_EDGES":
            Img = self.file.filter(ImageFilter.FIND_EDGES)
            path = ImgPath(self.mode, self.OutDirPath)
            Img.save(path)
        elif self.mode == "SMOOTH":
            Img = self.file.filter(ImageFilter.SMOOTH)
            path = ImgPath(self.mode, self.OutDirPath)
            Img.save(path)
        elif self.mode == "SMOOTH_MORE":
            Img = self.file.filter(ImageFilter.SMOOTH_MORE)
            path = ImgPath(self.mode, self.OutDirPath)
            Img.save(path)
        elif self.mode == "SHARPEN":
            Img = self.file.filter(ImageFilter.SHARPEN)
            path = ImgPath(self.mode, self.OutDirPath)
            Img.save(path)
        elif self.mode == "UnsharpMask":
            Img = self.file.filter(ImageFilter.UnsharpMask)
            path = ImgPath(self.mode, self.OutDirPath)
            Img.save(path)


def image_process():
    ObjDirPath, OutDirPath = file_process()
    ResultImg = check_fileExtension(os.listdir(ObjDirPath))
    for file in ResultImg:
        image_path = os.path.join(ObjDirPath, file)
        Img = Image.open(image_path)
        OutImgNames = ["BLUR", "CONTOUR", "DETAIL", "EDGE_ENHANCE", "EDGE_ENHANCE_MORE",
                       "EMBOSS", "FIND_EDGES", "SMOOTH", "SMOOTH_MORE", "SHARPEN", "UnsharpMask"]
        for mode in OutImgNames:
            Filter = ImgFilter(mode, Img, OutDirPath)
            Filter.SelectMode()


if __name__ == '__main__':
    image_process()
