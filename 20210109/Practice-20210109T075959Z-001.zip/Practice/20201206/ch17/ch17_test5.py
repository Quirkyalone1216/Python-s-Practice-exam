# ch17_20.py
from PIL import Image, ImageDraw
import os
import send2trash
import glob


def get_current_tree():
    """讀取當前檔案路徑和Resoures資料夾內的檔案名稱"""
    path = os.walk(os.getcwd())
    for dir_path, sub_dirNames, fileNames in path:
        obj_dir_path = os.path.join(dir_path, 'Resoures')
        files = os.listdir(obj_dir_path)
        return obj_dir_path, files


def check_file_extension(datas):
    """確認檔案副檔名"""
    result_img = []
    for data in datas:
        if data.lower().endswith(('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
            if data is not None:
                result_img.append(data)
    return result_img


def checkDir_exist(specific_path):
    Dir_exist = os.path.exists(specific_path)
    if Dir_exist is False:
        os.mkdir(specific_path)
    elif Dir_exist is True:
        list_file = []
        list_file1 = []
        for file1 in os.listdir(specific_path):
            list_file1.append(file1)
            for file in glob.glob('fig17_5.*'):
                list_file.append(file)
        if len(list_file) > 0:
            for file_exist in list_file:
                send2trash.send2trash(file_exist)
        elif len(list_file) == 0:
            return 1


def file_process():
    obj_dir_path, files = get_current_tree()
    outdir_path = os.path.join(obj_dir_path, 'Output')
    while 1:
        flag = checkDir_exist(outdir_path)
        if flag is 1:
            break
    return obj_dir_path, outdir_path


def check_fileExtension(datas):
    """確認檔案副檔名"""
    result_img = []
    for data in datas:
        if data.lower().endswith(('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
            if data is not None:
                result_img.append(data)
    return result_img


def ReDesignImage(OutDirPath):
    newImage = Image.new('RGBA', (300, 300), "Yellow")  # 建立300*300黃色底的影像
    drawObj = ImageDraw.Draw(newImage)
    # 繪製點
    for x in range(100, 200, 3):
        for y in range(100, 200, 3):
            drawObj.point([(x, y)], fill='Green')
    # 繪製線條, 繪外框線
    drawObj.line([(0, 0), (299, 0), (299, 299), (0, 299), (0, 0)], fill="Black")
    # 繪製右上角美工線
    for x in range(150, 300, 10):
        drawObj.line([(x, 0), (300, x-150)], fill="Blue")
    # 繪製左下角美工線
    for y in range(150, 300, 10):
        drawObj.line([(0, y), (y-150, 300)], fill="Blue")
    # 繪製左上角美工線
    for x in range(0, 150, 10):
        drawObj.line([(x, 0), (0, 150-x)], fill="Blue")
    # 繪製右下角美工線
    for y in range(0, 150, 10):
        drawObj.line([(300, 300-y), (y+150, 300)], fill="Blue")
    newImage.save(os.path.join(OutDirPath, "fig17_5.png"))


def img_process():
    """圖像處理"""
    obj_dir, outdir_path = file_process()
    result_file = os.listdir(obj_dir)
    result_img = check_file_extension(result_file)
    list_file = []
    for file in result_img:
        list_file.append(file)
        ReDesignImage(outdir_path)


if __name__ == '__main__':
    img_process()
