#ch15_test3
#Re-Design ch15_11.py
def division(x, y):
    try:                        # try - except指令
        return x / y
    except ZeroDivisionError:   # 除數為0使用
        return "除數為0發生"
    except TypeError:           # 資料型別錯誤
        return "除法運算資料型態異常"

def jugde_None(objs):
    for obj in objs:
        if not obj:
            print('輸入錯誤')
            objs = input('請重新輸入1個數字:')
        else:
            break
    return objs
def keyboard_in():
    in1 = input('請輸入第1個數字:')
    jugde_None(in1)
    in2 = input('請輸入第2個數字:')
    jugde_None(in2)
    return in1,in2
def main():
    in1,in2 = keyboard_in()
    in1 = int(in1)
    in2 = int(in2)
    ans = division(in1,in2)
    print(ans)
main()