#ch15_test5
#Re-Design ch15_11.py
def division(x, y):
    try:                        # try - except指令
        return x / y
    except Exception:           # 通用型錯誤
        return "資料輸入錯誤"

def jugde_None(objs):
    for obj in objs:
        if not obj:
            print('輸入錯誤')
            objs = input('請重新輸入1個數字:')
        else:
            break
    return objs
def keyboard_in():
    in1 = input('請輸入第1個數字:')
    jugde_None(in1)
    in2 = input('請輸入第2個數字:')
    jugde_None(in2)
    return in1, in2

def main():
    while 1:
        in1, in2 = keyboard_in()
        in1 = int(in1)
        in2 = int(in2)
        ans = division(in1, in2)
        print(ans)
        word = str(input('若要結束程式則輸入q或Q,若要繼續執行程式則按任意鍵:'))
        for words in word:
            if word == ('q' or 'Q'):
                break
        if word == ('q' or 'Q'):
            break

main()