from PIL import Image
import os
import send2trash
import glob


def get_current_tree(path):
    """讀取當前檔案路徑和Resoures資料夾內的檔案名稱"""
    for dir_path, sub_dirNames, fileNames in path:
        obj_dir = os.path.join(dir_path, 'Resoures')
        files = os.listdir(obj_dir)
        return obj_dir, files


def check_fileExtension(datas):
    """確認檔案副檔名"""
    result_img = []
    for data in datas:
        if data.lower().endswith(('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
            if data is not None:
                result_img.append(data)
    return result_img


def file_process():
    all_path = os.walk(os.getcwd())
    obj_dir, files = get_current_tree(all_path)
    outdir_path = os.path.join(obj_dir, 'Output')
    dir_exists = os.path.exists(outdir_path)
    if dir_exists is False:
        os.mkdir(outdir_path)
    elif dir_exists is True:
        list_files = []
        for file1 in os.listdir(outdir_path):
            for file in glob.glob('fig17_2.*'):
                list_files.append(file)
    if len(list_files) > 0:
        for file_exist in list_files:
            send2trash.send2trash(file_exist)
    elif len(list_files) == 0:
        return obj_dir, outdir_path


def ResizeImage(filein, outdir_path):
    """重新設計圖像,並輸出於Output資料夾"""
    img = Image.open(filein)
    re_img = img.resize((350, 500), Image.ANTIALIAS)
    re_img_path = os.path.join(outdir_path, "fig17_2.jpg")
    re_img.save(re_img_path)
    return re_img_path


def ImageCompose(resize_path):
    img = Image.open(resize_path)
    old_size = img.size
    new_size = (400, 550)
    new_image = Image.new("RGB", new_size)
    new_image.paste(img, (int((new_size[0]-old_size[0])/2), int((new_size[1]-old_size[1])/2)))
    new_image.save(resize_path)


def img_process():
    """圖像處理"""
    obj_dir, outdir_path = file_process()
    result_file = os.listdir(obj_dir)
    result_img = check_fileExtension(result_file)
    for file in result_img:
        image_path = os.path.join(obj_dir, file)
        resize_path = ResizeImage(image_path, outdir_path)
        ImageCompose(resize_path)


if __name__ == '__main__':
    img_process()