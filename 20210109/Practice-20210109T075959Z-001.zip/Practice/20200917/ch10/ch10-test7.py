#ch10-test7
#refenerce example_ch10-41.py
cocktail = {
    'Blue Hawaiian':{'Rum','Sweet Wine','Cream','Pineapple Juice','Lemon Juice'},
    'Ginger Mojito':{'Rum','Ginger','Mint Leaves','Lime Juice','Ginger Soda'},
    'New Yorker':{'Whiskey','Red Wine','Lemon Juice','Sugar Syrup'},
    'Bloody Mary':{'Vodka','Lemon Juice','Tomato Juice','Tabasco','little Sale'},
    'Horses Neck':{'brandy','ginger soda'},
    'Cosmopolitan':{'vodka','sweet wine','lime Juice','cranberry juice'},
    'Sex on the Beach':{'Peach Liqueur','vodka','orange juice','cranberry juice'}
    }
# 1：列出含有Vodka的酒。
print('含有Vodka的酒 : ')
for name, formulas in cocktail.items():
    if 'Vodka' in formulas or ('Vodka'.lower() in formulas):
        print(name)
# 2：列出含有Sweet Wine的酒。
print('含有Sweet Wine的酒 : ')
for name, formulas in cocktail.items():
    if 'Sweet Wine' in formulas or ('Sweet Wine'.lower() in formulas):
        print(name)
# 3：列出含有Vodka和Cranberry Juice的酒。
print('含有Vodka和Cranberry Juice的酒 : ')
for name, formulas in cocktail.items():
    if ('Vodka' and 'Cranberry Juice') in formulas or ('Vodka'.lower() and 'Cranberry Juice'.lower() in formulas):
        print(name)
# 4：列出含有Vodka但是沒有Cranberry Juice的酒。
print('含有Vodka但是沒有Cranberry Juice的酒 : ')
for name, formulas in cocktail.items():
    if ('Vodka' in formulas or ('Vodka'.lower() in formulas)) and not formulas & {'Cranberry Juice'.lower()}:
        print(name)

