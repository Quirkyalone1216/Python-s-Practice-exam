#ch12-test3
#Expand ch12-test1
class Myschool():
     school_name = 'Pyhton School'
     def __init__(self,user_name,user_score):
        self.name = user_name
        self.score = user_score
        self.title = Myschool.school_name

     def mag(self):
        print(my_school.title)
        return self.score

my_school = Myschool('kevin',80)
print('Hello!',my_school.name,'你的成績為',my_school.mag())