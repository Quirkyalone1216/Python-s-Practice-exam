#ch14_test2
import os

input_file = input("請輸入一個檔案名稱:")
input_file = str(input_file)
if os.path.exists(input_file):
    inFile_size = os.path.getsize(input_file)
    print(input_file," : ",inFile_size)
else:
    print(input_file,' ',"檔案不存在")