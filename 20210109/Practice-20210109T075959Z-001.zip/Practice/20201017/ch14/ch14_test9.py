#ch14_test9
import numpy as np
file_read = 'ex_14_6_1.txt'
with open(file_read,mode='r') as file_obj:
    obj_content = file_obj.readlines()
str_obj = ''
for line in obj_content:
    str_obj += line.rstrip()
print(str_obj)