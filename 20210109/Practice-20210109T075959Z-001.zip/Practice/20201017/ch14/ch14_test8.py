#ch14_test8
file_read = 'ex_14_6_1.txt'
with open(file_read,mode='r') as file_obj:
    for str_line in file_obj:
        print(str_line)