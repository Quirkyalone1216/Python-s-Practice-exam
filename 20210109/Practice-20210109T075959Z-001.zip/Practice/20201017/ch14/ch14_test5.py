#ch14_test5
file_read = 'data14_5.txt'
file_write = 'out14_5.txt'
with open(file_read,mode='r') as file_obj:
    data = str(file_obj.read())
with open(file_write,mode='w') as file_obj:
    file_obj.write(data)
print(data)