#ch14_test6
str1 = 'Python入門到高手之路'
str2 = '作者：洪錦魁'
str3 = '深石數位科技'
str4 = 'DeepStone Corporation'
str5 = 'Deep Learning'
str = [str1,str2,str3,str4,str5]
file_write_a = 'ex_14_6_1.txt'
file_write_b = 'ex_14_6_2.txt'
file_write_c = 'ex_14_6_3.txt'
with open(file_write_a,mode='w') as file_obj:
    str_obj = ''
    for i in range(len(str)):
        str_obj = str_obj + str[i] + '\n'
    file_obj.write(str_obj)
with open(file_write_b,mode='w') as file_obj:
    str_obj = ''
    for i in range(len(str)):
        str_obj += str[i]
    file_obj.write(str_obj)
with open(file_write_c,mode='w') as file_obj:
    str_obj = ''
    for i in range(len(str)):
        str_obj = str_obj + str[i] + '  '
    file_obj.write(str_obj)