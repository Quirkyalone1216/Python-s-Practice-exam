#ch14_test1
import os

input_dir = input("請輸入一個目錄名稱:")
input_dir = str(input_dir)
if os.path.exists(input_dir):
    print("已經存在 %s " % input_dir)
else:
    os.mkdir(input_dir)
    print("目錄 %s 不存在" % input_dir)
    print("開始建立 %s 目錄" % input_dir)
    print("建立 %s 資料夾成功" % input_dir)