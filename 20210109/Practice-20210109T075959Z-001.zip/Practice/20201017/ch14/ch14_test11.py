#ch14_test11
import shutil
from ch14.ch14_test10 import input_src_obj
file_source,file_object = input_src_obj()
shutil.copy(file_source,file_object)