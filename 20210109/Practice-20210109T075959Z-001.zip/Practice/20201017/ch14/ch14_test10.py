#ch14_test10
#Reference ch14_31_2.py
import os
def check_file_exist(file):
    if os.path.exists(file):
        return True
    else:
        return False
def input_src_obj():
    file_source = str(input('請輸入來源圖檔:'))
    for i in file_source:
        bool1 = check_file_exist(file_source)

        def re_input(obj):
            print("%s 不存在" % obj)
            obj = str(input('請輸入來源圖檔:'))
            return obj

        if bool1 != True:
            file_source = re_input(file_source)
        elif not file_source:
            file_source = re_input(file_source)
        elif bool1 == True:
            break
    file_object = str(input('請輸入目的圖檔:'))
    for j in file_object:
        bool2 = check_file_exist(file_object)

        def re_input(obj):
            print("%s 不存在" % obj)
            obj = str(input('請輸入目的圖檔:'))
            return obj

        if bool2 != True:
            file_object = re_input(file_object)
        elif not file_object:
            file_object = re_input(file_object)
        elif bool2 == True:
            break
    return file_source,file_object
file_temp = ''
file_source,file_object = input_src_obj()
with open(file_source, 'rb') as file_rd:
    file_temp = file_rd.read()
    with open(file_object, 'wb') as file_wr:
        file_wr.write(file_temp)