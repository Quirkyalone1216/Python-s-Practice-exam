#ch14_test3
#Re-Design ch14_13.py
import os
input_dir = str(input("請輸入一個目錄名稱:"))
for i in input_dir:
    if (str('"') or None) in input_dir:
        print("輸入錯誤")
        input_dir = str(input("請輸入一個目錄名稱:"))
        if str ('"') not in input_dir:
            break
if os.path.exists(input_dir):
    print("已經存在 %s " % input_dir)
    totalsizes = 0
    print("列出 %s 工作目錄的所有檔案" % input_dir)
    for file in os.listdir(input_dir):
        print(file)
        totalsizes += os.path.getsize(os.path.join(input_dir, file))
    print("全部檔案數量是 = ", len(os.listdir(input_dir)))
    print("全部檔案大小是 = ", totalsizes)
else:
    print("目錄 %s 不存在" % input_dir)