#ch14_test4
#Re-Design ch14_17.py

fn = 'ch14_test4.txt'          # 設定欲開啟的檔案
with open(fn) as file_Obj:  # 用預設mode=r開啟檔案,傳回檔案物件file_Obj
    data = file_Obj.read()  # 讀取檔案到變數data
    data = data.replace(' ','')
    data = data.replace('\n', '').replace('\r', '')  # \r 代表回車，也就是打印頭歸位，回到某一行的開頭。\n代表換行，就是走紙，下一行。
    print(data)