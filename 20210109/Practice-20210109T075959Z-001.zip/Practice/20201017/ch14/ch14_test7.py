#ch14_test7
file_read = 'ex_14_6_1.txt'
with open(file_read,mode='r') as file_obj:
    data = file_obj.read()
    print(data)