#ch2_test3
#page_2-15
principal=100000
annual_interest_rate=0.002
year=10
money=principal*(1+annual_interest_rate)**year
print (money)