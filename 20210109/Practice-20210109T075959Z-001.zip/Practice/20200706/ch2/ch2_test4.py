#ch2_test4
#page_2-15
apple_total=100
number_of_students=23
consume=1
daliy_count=apple_total//(number_of_students*consume)
apple_less=apple_total%(number_of_students*consume)
print (daliy_count,apple_less)