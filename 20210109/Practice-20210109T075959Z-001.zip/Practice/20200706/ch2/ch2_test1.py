#ch2-pratice question 1
#page_2-15
hourly_salary=150
annual_salary=hourly_salary*8*300
monthly_fee=9000
annual_fee=monthly_fee*12
annual_savings=annual_salary-annual_fee
print (annual_savings)