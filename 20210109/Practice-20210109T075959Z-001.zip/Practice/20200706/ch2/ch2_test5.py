#ch2_test5
distance=384400                 #earth to moon's distance/kilometer
rate=400                        #speed rate/per minute
time=distance/rate
print (time)                    #kilometer/per minute

