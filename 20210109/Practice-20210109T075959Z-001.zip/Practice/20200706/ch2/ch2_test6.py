#ch2_test6
PI=3.1415926535897932384626433
radius=20                                                 #cylinder-radius-centermeter
cylinder_high=30                                          #cylinder-high-centermeter
circle_area=PI*radius*radius                              #circle_area=PI*radius*radius
cylinder_area=circle_area*cylinder_high                   #cylinder_area=circle_area*cylinder_high
print (cylinder_area)