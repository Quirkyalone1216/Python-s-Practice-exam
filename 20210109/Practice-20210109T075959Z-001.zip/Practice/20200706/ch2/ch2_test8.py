#ch2_test8
import math

#part a
pi = 0
pi = 3 + (4 / 2 / 3 / 4) - (4 / 4 / 5 / 6) + (4 / 6 / 7 / 8)
print ("Part A",pi,"\n")

#part b
pi=0
pi = 3 + (4 / 2 / 3 / 4) - (4 / 4 / 5 / 6) + (4 / 6 / 7 / 8) - (4 / 8 / 9 / 10)
print ("Part b",pi,"\n")