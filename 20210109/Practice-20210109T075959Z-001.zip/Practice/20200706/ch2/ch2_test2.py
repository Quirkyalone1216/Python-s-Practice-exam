#ch2-pratice question 2
#page_2-15
#　利息（I）＝本金（P）×利率（i）×時間（t）
#usaualy using to calculate annual interest rate,should be div 360
principal=50000
interest_rate=0.015
time=360*5
interest=principal*interest_rate*time/360
print (interest)
