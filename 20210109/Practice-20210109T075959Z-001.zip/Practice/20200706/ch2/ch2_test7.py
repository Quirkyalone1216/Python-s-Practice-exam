#ch2_test7
#Leibniz-π
import math
def estimate_pi(terms):
    result = 0
    sign = 1
    for n in range (terms):
        result += sign / (2*n+1)
        sign = -sign
    return 4*result
print ("Part A",estimate_pi(5),"\n")
print ("Part B",estimate_pi(6),"\n")
print ("Part C",estimate_pi(7),"\n")