#ch3_test4
dist = 384400                       #earth to the moon distance-killometer
speed = 250                         #flying speed 250 kilometer/per minute
total_hours = dist // speed
days = total_hours // 24
hours = total_hours % 24
minutes = (round(((dist / speed) - (days * 24)) * 60))
if minutes >= 60:
    hours += minutes // 60
    minutes %= 60
print ("Days:",days)
print ("Hours:",hours)
print ("Minutes:",minutes)