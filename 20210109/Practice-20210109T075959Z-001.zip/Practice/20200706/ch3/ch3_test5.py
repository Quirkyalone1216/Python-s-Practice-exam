#ch3_test5
x="綱"
print(ord(x))