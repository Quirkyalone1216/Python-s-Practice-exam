#ch3_test1
#Assume a = 10    b = 18    c = 5

a = 10; b = 18 ; c = 5

#part a
s1 = a + b - c

#part b
s2 = (2 * a) + 3 - c

#part c
s3 = (b * c + 20) / b

#part d
s4 = a % c * b + 10

#part e
s5 = (a ** c) - (a * b * c)

print ("Part a",s1,"\n")
print ("Part b",s2,"\n")
print ("Part c",s3,"\n")
print ("Part d",s4,"\n")
print ("Part e",s5,"\n")