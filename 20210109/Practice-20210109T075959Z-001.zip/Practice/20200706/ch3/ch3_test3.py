#ch3_test3
#S＝1200×(1十4％×60／360)＝1208(元)
principal=50000
interest_rate=0.015+1
time=360*5
interest=principal*interest_rate*time/360
print (round(interest,1))
