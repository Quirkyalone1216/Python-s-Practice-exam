#ch3_test6
x='綱'
print (hex(ord(x)))