#ch13_test7
#Re-Design ch13_17_1.py
import random                       # 導入模組random
from tkinter import _flatten
import numpy
def dice():
    return random.choice([1, 2, 3, 4, 5, 6])

def dice_value():
    name = []
    for i in range(3):
        result = dice()
        result = str(result)
        names = locals()['name' + str(i)] = result  # Show in the variable's(name) value,variable name is 'names'
        name.insert(i, result)  # Apply value into the list(name)
        # print('name' + str(i) + ':' + names)       # view every single dice's value(name0:first_dice;nameN:N_dice)
    name = list(map(int, name))  # transfer data type (string to int)
    # print(name)                                    # view total random dice's vaule
    return name
def input_value():
    n = input('輸入要抽取幾組骰子值:')
    if not n:
        print('輸入錯誤')
        n = input('輸入要抽取幾組骰子值:')
    return int(n)
def dice_profile():
    n = input_value()
    total = []
    for i in range(n):
        result = dice_value()
        result = list(result)
        total.insert(i,result)
    total = list(_flatten(total))           #二維Array轉一維Array
    total = numpy.array(total)
    unique,count = numpy.unique(total,return_counts=True)
    print(dict(zip(unique,count)))
def main():
    dice_profile()
main()