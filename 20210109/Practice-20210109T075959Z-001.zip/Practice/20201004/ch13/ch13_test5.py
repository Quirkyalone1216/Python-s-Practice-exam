#ch13_test5
#Re-Design ch13_17.py
import random                       # 導入模組random

def del_list():
    fruits = ['蘋果', '香蕉', '西瓜', '水蜜桃', '百香果']
    print('執行程序前串列:', fruits)
    fruits_len = len(fruits)
    for i in range(fruits_len):
        remove_item = random.choice(fruits)
        fruits.remove(remove_item)
        print('刪除:', remove_item)
        print('目前串列:', fruits)

del_list()