#ch13_test4
import random
def dice_value():

    def dice():
        return int(random.randint(1, 6))

    name = []
    for i in range(3):
        result = dice()
        result = str(result)
        names = locals()['name' + str(i)] = result  # Show in the variable's(name) value,variable name is 'names'
        name.insert(i, result)                      # Apply value into the list(name)
        #print('name' + str(i) + ':' + names)       # view every single dice's value(name0:first_dice;nameN:N_dice)
    name = list(map(int, name))                     # transfer data type (string to int)
    #print(name)                                    # view total random dice's vaule
    return name
def main():
    n = input('輸入要抽取幾組骰子值:')
    if not n:
        print('輸入錯誤')
        n = input('輸入要抽取幾組骰子值:')
    n = int(n)
    for i in range(n):
        print(i+1,' :','隨機3組的骰子值 :',dice_value())
main()