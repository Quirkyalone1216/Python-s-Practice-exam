from PIL import Image
import pytesseract
import time
import os


def get_current_path():
    """Get Current Directory Path and list of 'Resoures' files"""
    path = os.walk(os.getcwd())
    for dir_path, sub_dir_names, files_name in path:
        obj_dir_path = os.path.join(dir_path, 'Resoures')
        files = os.listdir(obj_dir_path)
        return obj_dir_path, files


def file_extensions(file):
    """判斷檔案副檔名是否為圖像檔"""
    result_img = []
    for data in file:
        if data.lower().endswith(('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
            if data is not None:
                result_img.append(data)
    return result_img


def file_select():
    pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"
    obj_path, file = get_current_path()
    carDict = {}
    command_q = bool
    while 1:
        carPlate = input("請掃描或輸入車牌(Q/q代表結束) : ")
        while 1:
            if carPlate != 'Q' and carPlate != 'q':
                carPlate = obj_path + str('\\') + carPlate
                image_exist = os.path.exists(carPlate)
                if image_exist is True:
                    keyText = pytesseract.image_to_string(Image.open(carPlate))
                    if keyText in carDict:
                        exitTime = time.asctime()
                        print("車輛出場時間 : ", keyText, ":", exitTime)
                        del carDict[keyText]
                    else:
                        entryTime = time.asctime()
                        print("車輛入場時間 : ", keyText, ":", entryTime)
                        carDict[keyText] = entryTime
                        break
                elif image_exist is False:
                    print("輸入影像不存在")
                    break
            if carPlate == 'Q' or carPlate == 'q':
                command_q = True
                break
        if command_q is True:
            break


if __name__ == '__main__':
    file_select()
