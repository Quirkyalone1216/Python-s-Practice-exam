Tesseract-optical character recognition Noted

About Tesseract-ocr fail problem's solution describe website:
https://www.itread01.com/content/1546577344.html

Tesseract-ocr-setup-4.00.00dev.exe Download link:
http://digi.bib.uni-mannheim.de/tesseract/tesseract-ocr-setup-4.00.00dev.exe

