#ch6-test7
str = 'FBI Mark told CIA linda that the secret USB and given to FBI Peter'
str_particular_word = str.count("FBI")
print("FBI出現次數:",str_particular_word)
print("FBI置換為XX")
str = str.replace('FBI','XX')
print("新內容:",str)
