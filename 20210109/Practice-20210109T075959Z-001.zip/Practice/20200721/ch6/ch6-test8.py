#ch6-test8
print("判斷是否為網址字串")
In = input("請輸入一個字串:")
boolean_particular_word = In.startswith("http://") or In.startswith("https://")
if boolean_particular_word == True:
    print("這個字串是網路位址")
else:
    print("這個字串不是網路位址")