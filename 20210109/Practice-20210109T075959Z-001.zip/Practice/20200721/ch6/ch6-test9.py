#ch6-test9
str = 'Are you sleeping,are you sleeping,Brother John,Brother John?\n\
Morning bells are ringing,morning bells are ringing.\n\
Ding ding dong,Ding ding dong'
str_list1 = str.replace(',',' ')#逗號被空白取代
str_list2 = str_list1.replace('.',' ')#句點被空白取代
str_list3 = str_list2.replace('?',' ')#問號被空白取代
print("字串沒標點符號:",str_list3)
str_list4 = str_list3.replace(' ','')#分離空白
str_list5 = str_list4.replace('\n','')#分離換行\n
str_list5_word_count = len(str_list5)
print("歌曲的字數:",str_list5_word_count)
