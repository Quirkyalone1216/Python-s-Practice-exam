#ch6-test6
sc = [['洪錦魁',80,95,88,0,0],
      ['洪冰儒',98,97,96,0,0],
      ['洪雨星',90,91,92,0,0],
      ['洪冰雨',91,93,95,0,0],
      ['洪星宇',92,97,90,0,0],
     ]
sc[0][4] = sum(sc[0][1:4])
sc[1][4] = sum(sc[1][1:4])
sc[2][4] = sum(sc[2][1:4])
sc[3][4] = sum(sc[3][1:4])
sc[4][4] = sum(sc[4][1:4])
sc_list0_element_count = len(sc[0]) / 2
sc_list1_element_count = len(sc[1]) / 2
sc_list2_element_count = len(sc[2]) / 2
sc_list3_element_count = len(sc[3]) / 2
sc_list4_element_count = len(sc[4]) / 2
sc[0][5] = round(sc[0][4] / sc_list0_element_count,1)
sc[1][5] = round(sc[1][4] / sc_list1_element_count,1)
sc[2][5] = round(sc[2][4] / sc_list2_element_count,1)
sc[3][5] = round(sc[3][4] / sc_list3_element_count,1)
sc[4][5] = round(sc[4][4] / sc_list4_element_count,1)
print(sc[0])
print(sc[1])
print(sc[2])
print(sc[3])
print(sc[4])