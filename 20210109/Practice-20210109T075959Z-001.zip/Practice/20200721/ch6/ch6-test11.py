#ch6-test11
Data = ['Mary','Josh','Tracy']
