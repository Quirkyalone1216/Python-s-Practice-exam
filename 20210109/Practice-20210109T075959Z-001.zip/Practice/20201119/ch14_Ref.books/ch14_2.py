# ch14_2.py
import os

print(os.path.abspath('.'))              # 列出目前工作目錄的絕對路徑
print(os.path.abspath('..'))             # 列出上一層工作目錄的絕對路徑
print(os.path.abspath('ch14_2.py'))      # 列出目前檔案的絕對路徑






