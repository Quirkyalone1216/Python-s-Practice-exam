# ch14_34.py
import shutil

shutil.move('data34.txt', '.\\test34')  # 移動目前工作目錄data34.txt



