# ch14_9.py
import os

print(os.path.join('D:\\', 'Python', 'ch14', 'ch14_9.py'))   # 4個參數
print(os.path.join('D:\\Python', 'ch14', 'ch14_9.py'))       # 3個參數
print(os.path.join('D:\\Python\\ch14', 'ch14_9.py'))         # 2個參數




