# ch14_38.py
import shutil

shutil.move('dir38', 'D:\\Python\\out38')  



