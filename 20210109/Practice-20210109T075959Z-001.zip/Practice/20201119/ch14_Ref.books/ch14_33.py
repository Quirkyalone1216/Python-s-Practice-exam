# ch14_33.py
import shutil

shutil.copytree('old14', 'new14')                   # 目前工作目錄的目錄複製
shutil.copytree('D:\\Python\\old14', 'D:\\new14')   # 不同工作目錄的目錄複製


