# ch14_1.py
import os

print(os.getcwd())              # 列出目前工作目錄



