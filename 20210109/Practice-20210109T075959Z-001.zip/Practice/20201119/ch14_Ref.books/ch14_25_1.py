# ch14_25_1.py
msg = '''CIA Mark told CIA Linda that the secret USB
had given to CIA Peter'''
print("CIA最後出現位置: ", msg.rfind("CIA",0,len(msg)))








