#ch16_test4
import os,re


def get_current_tree(path):
    """讀取當前檔案路徑和ch14_Ref.books目錄內的檔案名稱"""
    for dir_path, sub_dirNames, fileNames in path:
        for sub_dirName in sub_dirNames:
            obj_dir = os.path.join(dir_path, 'ch14_Ref.books')
            files = os.listdir(obj_dir)
            return obj_dir, files

def check_fileExtension(datas):
    """確認檔案副檔名"""
    pattern_txt = r'.txt$'
    pattern_py = r'[1][0-9]+\.py$'
    result_txt = []
    result_py = []
    for data in datas:
        txt = re.search(pattern_txt,data)
        py = re.search(pattern_py,data)
        if txt is not None:
            result_txt.append(data)
        elif py is not None:
            result_py.append(data)
    return result_txt, result_py

if __name__ == '__main__':
    all_path = os.walk(os.getcwd())
    obj_dir,files = get_current_tree(all_path)
    result_txt,result_py = check_fileExtension(files)
    print(result_txt)
    print(result_py)

