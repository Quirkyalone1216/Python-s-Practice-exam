#ch6-test11
Data = ['Mary','Josh','Tracy']
print("目前邀請名單",Data)
choice = input("選擇1,可以增加一位邀請名單\n選擇2,可以刪除一位邀請名單:")
if choice=='1':
    Data_add = input("增加名單:")
    if Data_add in Data:
        print("增加名單已在邀請名單內")
    else:
        Data.append(Data_add)
elif choice=='2':
    Data_delete = input("刪除名單:")
    if Data_delete in Data:
        Data.remove(Data_delete)
    else:
        print("刪除名單不在邀請名單內")
print("目前邀請名單",Data)