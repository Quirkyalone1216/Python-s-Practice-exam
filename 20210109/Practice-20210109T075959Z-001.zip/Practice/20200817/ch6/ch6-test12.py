#ch6-test12
eng_str = 'abcdefghijklmnopqrstuvwxyz'
front5 = eng_str[:5]
end21 = eng_str[5:]
subText = end21 + front5
print(subText)
subText = front5 + end21
print(subText)