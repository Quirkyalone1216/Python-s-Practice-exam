#ch7-test1
elements = ['da1.jpg','da2.png','da3.gif','da4.gif','da5.jpg','da6.jpg','da7.gif']
jpg = []
png = []
gif = []
for element in elements:
    if element.endswith('.jpg'):
        jpg.append(element)
    elif element.endswith('.png'):
        png.append(element)
    elif element.endswith('.gif'):
        gif.append(element)
print(".jpg",jpg)
print(".png",png)
print(".gif",gif)