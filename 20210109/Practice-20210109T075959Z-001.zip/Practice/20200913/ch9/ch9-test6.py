#ch9-test6
armys = []
#Build number of fifty soldier
for soldier_number in range(50):
    soldier = {'tag':'red','score':3,'speed':'slow'}
    armys.append(soldier)
#print first three digits soldier
print("前三名小兵資料")
for soldier in armys[0:3]:
    print(soldier)
#change last three digits's soldier
for soldier in armys[47-1:50]:
    if soldier['tag']=='red':
        soldier['tag']='green'
        soldier['score']=10
        soldier['speed']='fast'
#print number of 45 to 50's soldier
print("列印編號45到50的小兵資料")
for soldier in armys[45-1:50]:
    print(soldier)