#ch9-test4
noodles = {'牛肉麵':100,'肉絲麵':80,'陽春麵':60,'大滷麵':90,'麻醬麵':70}
print(noodles)
noodles_list = sorted(noodles.items(),key=lambda item:item[1])
print(noodles_list)