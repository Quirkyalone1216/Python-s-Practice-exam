#ch9-test3
fruits = {'Watermelon':15,'Banana':20,'Pineapple':25,'Orange':12,'Apple':18}
print("Not sorted:",fruits)
fruits_sorted = sorted(fruits)
print("Had been sorted",fruits_sorted)