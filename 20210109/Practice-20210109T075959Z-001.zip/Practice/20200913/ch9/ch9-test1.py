#ch9-test1
import re
week = {'Monday':'星期一','Tuesday':'星期二','Wednesday':'星期三','Thursday':'星期四','Friday':'星期五',
        'Saturday':'星期六','Sunday':'星期日'}
#judgement input value is Chinese or not
def judgement_chinese(search):
    for char in search:
        if '\u4e00' <= char <= '\u9fa5':
            return True
    return False
search = input("Input to search week information:")
judgement_chinese(search)
if judgement_chinese(search)==False:
    searched = search.title()
    value = week.get(searched)
    if value == None:
        print("Enter Error")
    elif value != None:
        print(week.get(searched))
elif judgement_chinese(search)==True:
    print("Entered Error")