#ch9-test2
month = {'一月':'January','二月':'February','三月':'March','四月':'April','五月':'May','六月':'June',
         '七月':'July','八月':'August','九月':'September','十月':'October','十一月':'November','十二月':'December'}
#judgement input value is Chinese or not
def judgement_chinese(value_input):
    for char in value_input:
        if '\u4e00' <= char <= '\u9fa5':
            return True
    return False
value_input = input("輸入中文的月份:")
judgement_chinese(value_input)
if judgement_chinese(value_input)==True:
    search = month.get(value_input)
    if search == None:
        print("輸入錯誤")
    elif search != None:
        print(search)
elif judgement_chinese(value_input)==False:
    print("輸入錯誤")