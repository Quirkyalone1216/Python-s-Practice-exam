#ch8-test7
number_of_visitors = (1100,652,946,821,955,1024,1155)
#average value
average = sum(number_of_visitors)/len(number_of_visitors)
print("平均值:",round(average,2))
#計算變異數
var = 0
for v in number_of_visitors:
    var += ((v - average)**2)
var = var / (len(number_of_visitors)-1)
print("變異數:",round(var,2))
#計算標準差
dev = 0
for v in number_of_visitors:
    dev += ((v - average)**2)
dev = (dev / (len(number_of_visitors)-1))
print("標準差:",round(dev,2))