#ch8-test6
import numpy as np
Max_temperature = (30,28,29,31,33,35,32)
Min_temperature = (20,21,19,22,23,24,20)
resultList = np.concatenate([Max_temperature,Min_temperature])
average = sum(resultList)/len(resultList)
print("最高溫:",max(Max_temperature))
print("最低溫:",min(Min_temperature))
print("平均溫度:",round(average,3))