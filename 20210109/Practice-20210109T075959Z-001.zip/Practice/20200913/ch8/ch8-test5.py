#ch8-test5
season = ('Spring','Summer','Fall','Winter')
chinese = ('春季','夏季','秋季','冬季')
zipData = zip(season,chinese)
result = list(zipData)
print(result)