#ch8-test4
tp = (1,2,3,4,5,2,3,1,4)
list = list(tp)
resultList = []
for item in list:
    if not item in resultList:
        resultList.append(item)
newtp = tuple(resultList)
print("Original-Tuple:",tp)
print("Compared-Tuple:",newtp)