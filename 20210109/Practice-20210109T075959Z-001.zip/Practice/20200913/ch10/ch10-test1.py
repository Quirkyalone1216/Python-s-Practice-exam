#ch10-test1
Paragraph = "Silicon Stone Education is an unbiased organization, concentrated on\
bridging the gap between academic and the working world in order to\
benefit society as a whole. We have carefully crafted our online\
certification system and test content databases. The content for each\
topic is created by experts and is all carefully designed with a\
comprehensive knowledge to greatly benefit all candidates who\
participate."
mydict = {}
paragraph_lower = Paragraph.lower()
print(type(Paragraph))
Paragraph_Lower = Paragraph
for ch in Paragraph_Lower:
    if ch in ".,?":
        Paragraph_Lower = Paragraph_Lower.replace(ch,'')
ParagraphList = Paragraph_Lower.split()
print(ParagraphList)
mydict = set(ParagraphList) # 將串列轉成集合
mydict_D = list(mydict)     # 將集合轉成串列
print(mydict)