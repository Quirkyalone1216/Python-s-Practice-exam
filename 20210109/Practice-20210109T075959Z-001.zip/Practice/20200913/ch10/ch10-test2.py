#ch10-test2
A = { i for i in range(1,100+1,2)}      #1,3,5,...,99
B = { i for i in range(0,100+1,5)}      #0,5,10,...,100
x = A & B                               #x是A集合與B集合的交集(intersection)
print("A和B的交集是",x)
AorB = A.union(B)                       #A集合和B集合的聯集(Union)
print("A和B的聯集",AorB)
# 將difference( )應用在A集合
A_B_difference = A.difference(B)        #A-B的差集
print("A-B的差集是", A_B_difference)
# 將difference( )應用在B集合
B_A_difference = B.difference(A)        #B-A的差集
print("B-A的差集是", B_A_difference)