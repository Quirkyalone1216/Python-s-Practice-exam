#ch10-test3
Math = {'Peter', 'Norton', 'Kevin', 'Mary', 'John', 'Ford', 'Nelson', 'Damon', 'Ivan','Tom'}
Computer = {'Curry', 'James', 'Mary', 'Turisa', 'Tracy', 'Judy', 'Lee', 'Jarmul','Damon', 'Ivan'}
Physics = {'Eric', 'Lee', 'Kevin', 'Mary', 'Christy', 'Josh', 'Nelson', 'Kazil', 'Linda', 'Tom'}
a = Math & Computer & Physics           #a：同時參加3個夏令營的名單。
b = Math & Computer                     #b：同時參加Math和Computer的夏令營的名單。
c = Math & Physics                      #c：同時參加Math和Physics的夏令營的名單。
d = Computer & Physics                  #d：同時參加Computer和Pyhsics的夏令營的名單。
print("a=",a,'\n',"b=",b,'\n',"c",c,'\n',"d",d)
