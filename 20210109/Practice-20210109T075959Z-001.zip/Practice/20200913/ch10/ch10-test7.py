#ch10-test7(Reference ch10-41.py)
cocktail = {
    'Blue Hawaiian':{'Rum','Sweet Wine','Cream','Pineapple Juice','Lemon Juice'},
    'Ginger Mojito':{'Rum','Ginger','Mint Leaves','Lime Juice','Ginger Soda'},
    'New Yorker':{'Whiskey','Red Wine','Lemon Juice','Sugar Syrup'},
    'Bloody Mary':{'Vodka','Lemon Juice','Tomato Juice','Tabasco','little Sale'},
    'Horse’s Neck':{'brandy','ginger soda'},
    'Cosmopolitan':{'vodka','sweet wine','lime Juice','cranberry juice'},
    'Sex on the Beach':{'vodka','Peach Liqueur','orange juice','cranberry juice'}
    }
#1：列出含有Vodka的酒。
print("含有Vodka的酒 : ")
for name, formulas in cocktail.items():
    if 'Vodka' in formulas:
        print(name)
# 2：列出含有Sweet Wine的酒。
print("含有Sweet Wine的酒 : ")
for name, formulas in cocktail.items():
    if 'Sweet Wine' in formulas:
        print(name)
# 3：列出含有Vodka和Cranberry Juice的酒。
print("含有Vodka和Cranberry Juice的酒 : ")
for name, formulas in cocktail.items():
    if 'Vodka'  and 'Cranberry Juice' in formulas:
        print(name)
# 4：列出含有Vodka但是沒有Cranberry Juice的酒。
print("含有Vodka但是沒有Cranberry Juice的酒 : ")
for name, formulas in cocktail.items():
    if 'Vodka' in formulas and not formulas & {'Cranberry Juice'}:
        print(name)