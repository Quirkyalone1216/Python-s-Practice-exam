#ch10-test5(Reference ch9-test9)
The_Zen_of_Python = "The Zen of Python, by Tim Peters\
Beautiful is better than ugly.\
Explicit is better than implicit.\
Simple is better than complex.\
Complex is better than complicated.\
Flat is better than nested.\
Sparse is better than dense.\
Readability counts.\
Special cases aren't special enough to break the rules.\
Although practicality beats purity.\
Errors should never pass silently.\
Unless explicitly silenced.\
In the face of ambiguity, refuse the temptation to guess.\
There should be one-- and preferably only one --obvious way to do it.\
Although that way may not be obvious at first unless you're Dutch.\
Now is better than never.\
Although never is often better than *right* now.\
If the implementation is hard to explain, it's a bad idea.\
If the implementation is easy to explain, it may be a good idea.\
Namespaces are one honking great idea -- let's do more of those!"
mydict = {}                         # 空字典未來儲存單字計數結果
# 以下是將大寫字母全部改成小寫
Python_Lower = The_Zen_of_Python.lower()            # 改為小寫

# 將標點符號用空字元取代
for ch in Python_Lower:
        if ch in ".,?":
            Python_Lower = Python_Lower.replace(ch,'')

# 將字串轉成串列
PythonList = Python_Lower.split()

# 將串列處理成字典
for wd in PythonList:
    if wd in mydict:  # 檢查此字是否已在字典內
        mydict[wd] += 1  # 累計出現次數
    else:
        mydict[wd] = 1  # 第一次出現的字建立此鍵與值

print("以下是最後執行結果")
print(mydict)  # 列印字典
