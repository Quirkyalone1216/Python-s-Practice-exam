#ch10-test4
#x介於2~101(不含)之間	如果  	所有2~x(不含)的數字都不能整除x
#result = [	x for x in range(2, 101)	if	all(x % i for i in range(2, x))	]
A = [a for a in range(1,99+1,2)]
B = [b for b in range(2, 101) if all(b % i for i in range(2, b))]
set_A = set(A)
set_B = set(B)
intersection = set_A & set_B                    #A串列與B串列的交集(intersection)
print("A串列與B串列的交集:",intersection)
union = set_A | set_B                           #A串列與B串列的聯集(Union)
print("A串列與B串列的聯集:",union)
# 將difference( )應用在A集合
A_B_difference = set_A - set_B                  #A-B的差集
print("A-B的差集是", A_B_difference)
# 將difference( )應用在B集合
B_A_difference = set_B - set_A                  #B-A的差集
print("B-A的差集是", B_A_difference)
A_sydi_B = set_A ^ set_B                        #AB對稱差集
print("AB對稱差集:",A_sydi_B)
B_sydi_A = set_B ^ set_A                        #BA對稱差集
print("BA對稱差集",B_sydi_A)