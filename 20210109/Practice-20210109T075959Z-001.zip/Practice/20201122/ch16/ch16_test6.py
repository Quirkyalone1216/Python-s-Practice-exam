#ch16_test6
#Re-Design ch16_39.py
import re
if __name__ == '__main__':
    msg = '''txt@deepstone.com.tw kkk@gmail.com
    abc@me.com mymail@qq.com abc@abc@abc'''
    pattern = r'''(
        [a-zA-Z0-9_.]+                  # 使用者帳號
        @                               # @符號
        [a-zA-Z0-9-.]+                  # 主機域名domain
        [\.]                            # .符號
        [a-zA-Z]{2,4}                   # 可能是com或edu或其它
        ([\.])?                         # .符號, 也可能無特別是美國
        ([a-zA-Z]{2,4})?                # 國別
        )'''
    eMail = re.findall(pattern, msg, re.VERBOSE)  # 傳回搜尋結果
    pattern1 = r'([a-zA-Z0-9_.])+@([a-zA-Z0-9-.])+([\.])+([a-zA-Z]{2,4})'
    reuslts = []
    reuslts1 = []
    reuslts2 = []
    for mail in eMail:
        temp_result1 = list(mail)
        for temp1 in temp_result1:
            reuslts.append(temp1)
    for reuslt in reuslts:
        temp_result2 = re.search(pattern1, reuslt)
        if temp_result2 is not None:
            reuslts1.append(temp_result2.group())
    for reuslt1 in reuslts1:
        print(reuslt1)
