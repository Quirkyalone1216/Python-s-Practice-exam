#ch3_test7
string = '王者歸來'
stringBytes = string.encode('utf-8')
type(stringBytes)
print (stringBytes)

