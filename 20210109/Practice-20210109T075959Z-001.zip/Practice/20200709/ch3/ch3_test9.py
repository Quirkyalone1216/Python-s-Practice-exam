#ch3_test9
x1 = 1
y1 = 8
x2 = 3
y2 = 10
dist = (((x1 - x2)** 2) + ((y1 - y2)** 2))** 0.5
print ("兩點距離為",dist)