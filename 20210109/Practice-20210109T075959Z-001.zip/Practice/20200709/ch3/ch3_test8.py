#ch3_test8
dist = 384400                   #The distance of the moon to the earth
speed = 1225                    #1225 kilometer for hour(1 Mach)
total_hour = dist // speed
days, hours = divmod(total_hour , 24)
calculate_hour = dist / speed - (days * 24)
mins = calculate_hour * 60
if mins >= 60:
    added_hour = mins // 60
    hours += added_hour
    calculate_min = mins - (added_hour * 60)
    mins = calculate_min - 1
    secs = 0.7959183673469283 * 60
print (calculate_hour)
print ("總共需要",days,"天")
print ("總共需要",hours,"小時")
print ("總共需要",round(mins,0),"分鐘")
print ("總共需要",round(secs,0),"秒")