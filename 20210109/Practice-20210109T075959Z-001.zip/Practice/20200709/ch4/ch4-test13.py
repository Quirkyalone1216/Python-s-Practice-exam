#ch4-test13
#正多邊形面積計算公式
#area=(n*(s**2))/(4*tan(PI/n))
import math

n = input("請輸入正n邊形:")
s = input("請輸入正%s邊形邊長:"%n)
area = (float(n) * (float(s) ** 2)) / (4 * math.tan(math.pi / float(n)))
print("area=",area)
