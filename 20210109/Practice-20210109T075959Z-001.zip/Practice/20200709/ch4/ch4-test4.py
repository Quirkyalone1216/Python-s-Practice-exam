#ch4-test4
number = eval(input("請輸入3位數的數字:"))
if number>= 1000:
    print("您輸入數字已超過3位數!!")
else:
    digits = number % 10
    ten_digits = number // 10
    if digits!=0:
        number = ten_digits * 10
        print("您輸入的數字為", number)
    else:
        print("您輸入的數字為", number)
