# ch4_test2
name1 = "洪冰儒"
name2 = "洪雨星"
name3 = "洪冰雨"
name4 = "洪星宇"
suj_chinese_name1 = 98
suj_chinese_name2 = 96
suj_chinese_name3 = 92
suj_chinese_name4 = 93
suj_english_name1 = 90
suj_english_name2 = 95
suj_english_name3 = 88
suj_english_name4 = 97
total_name1 = suj_chinese_name1 + suj_english_name1
average1 = total_name1 / 2
total_name2 = suj_chinese_name2 + suj_english_name2
average2 = total_name2 / 2
total_name3 = suj_chinese_name3 + suj_english_name3
average3 = total_name3 / 2
total_name4 = suj_chinese_name4 + suj_english_name4
average4 = total_name4 / 2
print(" 姓名      國文      英文     總分     平均")
print("%3s    %4d     %4d     %4d     %4.1f" % (name1, suj_chinese_name1, suj_english_name1, total_name1, average1))
print("%3s    %4d     %4d     %4d     %4.1f" % (name3, suj_chinese_name3, suj_english_name3, total_name3, average3))
print("%3s    %4d     %4d     %4d     %4.1f" % (name4, suj_chinese_name4, suj_english_name4, total_name4, average4))
