#ch4-test10
distance = 384400
speed = input("請輸入飛行速度(馬赫):")
temp = float(speed) * 1225
total_hours = distance // temp
days = total_hours // 24
hours = total_hours % 24
kph = distance / total_hours
print("Kph:%d(km/h)"%kph)
print("總共需要%d天數"%days)
print("總共需要%d小時"%hours)

