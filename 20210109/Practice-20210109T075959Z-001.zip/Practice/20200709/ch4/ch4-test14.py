#ch4-test14
#distance=r*acos(sin(x1)*sin(x2)+cos(x1)*cos(x2)*cos(y1-y2))
#radius=6371    the earth radius(kilometer)
import math
x1 = input("第1個的地點x座標:")
y1 = input("第1個的地點y座標:")
x2 = input("第2個的地點x座標:")
y2 = input("第2個的地點y座標:")
radius = 6371
distance = radius * math.acos(math.sin(math.radians(float(x1)))*math.sin(math.radians(float(x2)))+
                              math.cos(math.radians(float(x1)))*math.cos(math.radians(float(x2)))*
                              math.cos(math.radians(float(y1) - float(y2))))
print("distance=",distance)