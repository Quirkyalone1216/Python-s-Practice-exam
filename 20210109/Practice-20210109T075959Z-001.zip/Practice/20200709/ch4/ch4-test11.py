#ch4-test11
x1 = input("請輸入第1個座標點x:")
y1 = input("請輸入第1個座標點y:")
x2 = input("請輸入第2個座標點x:")
y2 = input("請輸入第2個座標點y:")
distance = ((float(x1) - float(x2))**2 + ((float(y1) - float(y2))**2))** 0.5
print("第1個座標點與第2個座標點的距離為%.2f"%distance)