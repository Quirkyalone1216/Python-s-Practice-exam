#ch4-test12
#p=(dist1+dist2+dist3)/2
#area=(p*(p-dist1)*(p-dist2)*(p-dist3))**0.5
#海龍公式
dist1 = input("請輸入三角形第1個邊長:")
dist2 = input("請輸入三角形第2個邊長:")
dist3 = input("請輸入三角形第3個邊長:")
p = ((float(dist1))+(float(dist2))+(float(dist3))) / 2
area = (p*(p-float(dist1))*(p-float(dist2))*(p-float(dist3)))**0.5
print("三角形面積為%d"%area)