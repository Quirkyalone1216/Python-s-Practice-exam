#ch4-test5
# c=(f-32)*5/9
# f=c*9/5+32
c = input("請輸入攝氏溫度:")
f= (int(c) * (9 / 5)) + 32
print("華氏溫度為%4.1fF" % f)
