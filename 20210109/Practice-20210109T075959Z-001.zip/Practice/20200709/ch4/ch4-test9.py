#ch4-test9
distance=384400                 #earth to moon's distance/kilometer
rate=input("請輸入飛行速度:")                        #speed rate/per minute
time=distance/float(rate)
print ("飛行所消耗時間為%d分鐘"%time)                    #kilometer/per minute