#ch4_test8
annual_interest_rate = input("請輸入年利率:")
savings_money = input("請輸入存款金額:")
money = float(savings_money) * ((1 + float(annual_interest_rate)) ** 5)
print("運算後本金和為%d" % money)