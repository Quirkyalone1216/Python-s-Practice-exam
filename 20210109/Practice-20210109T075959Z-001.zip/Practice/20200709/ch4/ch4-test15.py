#ch4-test15
#Ausse the aircraft take off's speed is v,the aircraft's acceleration is a.
#the following are the aircraft when take off require's runway length equation
#distance=(v**2) / (2*a)
