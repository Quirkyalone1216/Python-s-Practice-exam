#ch4-test6
#one level ground about 3.305 square meter
level_ground = input("請輸入建築坪數:")
square_meter = int(level_ground) * 3.305
print("建築為%10.1f平方公尺" % square_meter)