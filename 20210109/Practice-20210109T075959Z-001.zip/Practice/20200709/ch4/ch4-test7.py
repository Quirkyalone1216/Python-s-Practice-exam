#ch4-test7
#one level ground about 3.305 square meter
square_meter = input("請輸入建築面積(平方公尺):")
level_ground = int(square_meter) / 3.305
print("建築為%10.1f坪" % level_ground)