#ch5-test3
#到圓心的距離 是否大於半徑。
#半徑是R 如O(x,y)點圓心，任意一點P（x1,y1） （x-x1）*(x-x1)+(y-y1)*(y-y1)>R*R 那麼在圓外反之在圓內
radius = input("請輸入半徑:")
x = input("請輸入座標x:")
y = input("請輸入座標y:")
if ((float(x)**2)+(float(y)**2))<= float(radius)**2:
    print("此座標點在圓內部")
else:
    print("此座標點不在圓內部")

