#ch5-test2
print("輸入3個數,由大到小輸出")
x = input("請輸入第1個數:")
y = input("請輸入第2個數:")
z = input("請輸入第3個數:")
score = [float(x) ,float(y) ,float(z)]
score = sorted(score, reverse=True)
print(score)