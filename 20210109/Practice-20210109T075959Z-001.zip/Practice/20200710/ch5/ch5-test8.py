#ch5-test8
#问题描述：编写程序，从键盘输入三条边，判断是否能够构成一个三角形。
#问题分析：组成三角形的条件是任意两边之和大于第三边，如果条件成立，则能构成三角形。
# 条件表达式中的多个条件必须全部成立。
side1 = float(input("The first side of triangle:"))
side2 = float(input("The second side of triangle:"))
side3 = float(input("The third side of triangle:"))
if side1 + side2 > side3 and side2 + side3 > side1 and side1 + side3 > side2:
    print("三角形成立")
else:
    print("三角形不成立")