#ch5-test6
working_hours = input("請輸入工作時數:")
minimum_wage = input("請輸入工作基本時薪:")
if float(working_hours) < 40:
    mul_rate = 0.8
elif float(working_hours) == 40:
    mul_rate = 1
elif float(working_hours) > 40 or float(working_hours) <= 50:
    mul_rate = 1.2
elif float(working_hours) > 50:
    mul_rate = 1.6
weekly_salary = float(minimum_wage) * float(mul_rate) * float(working_hours)
print("週薪為",float(weekly_salary))