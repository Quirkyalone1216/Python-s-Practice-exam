#ch5-test10
#(ax)**2 + b*x + c = 0
print("輸入三個數值,計算一元二次方程式的根")
a = float(input("輸入第1個數:"))
b = float(input("輸入第2個數:"))
c = float(input("輸入第3個數:"))
r1 = (-b + (b**2-4*a*c)**0.5)/(2*a)
r2 = (-b - (b**2-4*a*c)**0.5)/(2*a)
print("r1=",r1,",      ","r2=",r2)