#ch5-test7
print("Ausse today is Sunday")
count_days = input("請輸入天數:")
count_weeks = float(count_days) // 7
after_days = float(count_days) % 7

if count_weeks > 0:
    print("%d天後是下%d週的星期%d" % (int(count_days), int(count_weeks),int(after_days)))
elif count_weeks == 0:
    print("%d天後是這週的%d" % (int(count_days), int(count_weeks),int(after_days)))
