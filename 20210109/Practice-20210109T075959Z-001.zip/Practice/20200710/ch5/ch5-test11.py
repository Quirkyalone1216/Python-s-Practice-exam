#ch5-test11
a,b,c,d,e,f = map(float,input("請輸入a,b,c,d,e,f數值(以逗號相隔):").split(",",5))
x = (e*d - b*f) / (a*d - b*c)
y = (a*f - e*c) / (a*d - b*c)
print("x=",x,"      ","y=",y)