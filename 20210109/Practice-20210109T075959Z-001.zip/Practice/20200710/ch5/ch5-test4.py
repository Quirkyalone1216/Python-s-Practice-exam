#ch5-test4
print("輸入一個數,正負顛倒輸出")
x = input("請輸入1個數:")
if float (x)>0:
    x = -float(x)
elif float(x)<0:
    x = -float(x)
else:
    x = float(x)
print("輸出結果:",x)