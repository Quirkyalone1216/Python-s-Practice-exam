#ch5-test5
#c=(f-32)*5/9
#f=c*(9/5)+32
choice_f = input("華氏溫度轉換攝氏溫度,輸入y或Y代表使用此換算法,輸入其他代表不使用:")
if choice_f == "y" or choice_f == "Y":
    F = 1
    if F == 1:
        temp_f = input("請輸入華氏溫度:")
        temp_c = (float(temp_f) - 32) * 5 / 9
        print("換算完為攝氏%6.1f度"%float(temp_c))
else:
    F = 0
    choice_c =  input("攝氏溫度轉換華氏溫度,輸入y或Y代表使用此換算法,輸入其他代表不使用:")
    if choice_c == "y" or choice_c == "Y":
        C = 1
        if C == 1:
            temp_c = input("請輸入攝氏溫度:")
            temp_f = float(temp_c) * (9 / 5) + 32
            print("換算完為華氏%6.1f度" % float(temp_f))
    else:
        C = 0
if F == 0 and C == 0:
    print("未選擇溫度換算算法,程式結束")