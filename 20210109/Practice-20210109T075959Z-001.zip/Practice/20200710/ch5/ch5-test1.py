#ch5-test1
print("輸出絕對值")
num = input("請輸入任意整數值:")
x = int(num)
if x >= 0:
    x = x
else:
    x = -x
print("絕對值是%d"%int(x))