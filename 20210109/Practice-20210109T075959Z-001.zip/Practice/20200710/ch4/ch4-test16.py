#ch4-test16
#distance=radius*acos(sin(x1)*sin(x2)+cos(x1)*cos(x2)*cos(y1-y2))
#radians弧度
import  math
x1 = 39.9196
y1 = 116.3669
x2 = 48.8595
y2 = 2.3369
radius = 6371
distance = radius * math.acos(math.sin(math.radians(x1))*math.sin(math.radians(x2)) +
                              math.cos(math.radians(x1))*math.cos(math.radians(x2)) *
                              math.cos(math.radians(y1 - y2)))
print("計算後2博物館之間距離為",distance)