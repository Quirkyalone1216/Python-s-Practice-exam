#ch4-test15
#Ausse the aircraft take off's speed is v,the aircraft's acceleration is a.
#the following are the aircraft when take off require's runway length equation
#distance=(v**2) / (2*a)
v = input("請輸入飛機起飛的速度v(m/s):")
a = input("請輸入飛機的加速度a(m/s):")
distance = (float(v)**2) / (2 * float(a))
print("飛機所需跑道長度為%d"%distance)