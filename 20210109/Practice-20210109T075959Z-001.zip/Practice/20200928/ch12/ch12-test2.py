#ch12-test2
class Myschool():
    def __init__(self,user_name,user_score):
        self.name = user_name
        self.score = user_score
    def msg(name,score):
        print("Hello!",name,"你的成績為",score)
hung = Myschool.msg('kevin',80)