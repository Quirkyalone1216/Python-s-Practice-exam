#ch12-test1
class Myschool():
     title = '明志科大'
     def department(self):
        xlist = ["機械","電機","化工"]
        str_number = len(xlist)
        for i in range(0,str_number):
            print(xlist[i])
            if i==2:
                return i
userMyschool = Myschool()
print(userMyschool.title)
if userMyschool.department()<2:
    print(userMyschool.department())