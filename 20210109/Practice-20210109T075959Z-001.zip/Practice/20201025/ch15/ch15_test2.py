#ch15_test2
#Re-Design ch15_8.py
open_file = 'output\d1.txt'       #File location example

def wordsNum(fn):
    """適用英文文件, 輸入文章的檔案名稱,可以計算此文章的字數"""
    try:
        with open(fn) as file_Obj:  # 用預設"r"傳回檔案物件file_Obj
            data = file_Obj.read()  # 讀取檔案到變數data
    except FileNotFoundError:
        print("找不到 %s 檔案" % fn)
    else:
        wordList = data.split()     # 將文章轉成串列
        print(fn, " 文章的字數是 ", len(wordList))    # 列印文章字數

def jugde_None(objs):
    for obj in objs:
        if not obj:
            print('輸入錯誤')
            objs = str(input('請輸入檔案名稱:'))
        else:
            break
    return objs

def keyborad_in():
    while 1:
        file_input = str(input('請輸入檔案名稱:'))
        file_input = jugde_None(file_input)
        wordsNum(file_input)
        word = str(input('若要結束程式則輸入q或Q,若要繼續執行程式則按任意鍵:'))
        for words in word:
            if word == ('q' or 'Q'):
                break
        if word == ('q' or 'Q'):
            break

def main():
    keyborad_in()

main()