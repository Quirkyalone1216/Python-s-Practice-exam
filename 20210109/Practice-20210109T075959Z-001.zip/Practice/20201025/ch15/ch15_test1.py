#ch15_test1
#Re-Design ch15_6.py
import ch15.output
fn = 'output\ch15_test1.txt'               # 設定欲開啟的檔案
def in_word():
    string = str(input('請輸入文字:'))
    for word in string:
        if word == None:
            print('輸入文字為空')
            string = str(input('請輸入文字:'))
        elif word != None:
            break
    return string

def word_wr(word):
    try:
        with open(fn, mode='w') as file_obj:
            data = file_obj.write(word)
    except FileNotFoundError:
        print("找不到 %s 檔案" % fn)

def word_rd():
    try:
        with open(fn) as file_Obj:  # 用預設mode=r開啟檔案,傳回檔案物件file_Obj
            data = file_Obj.read()  # 讀取檔案到變數data
    except FileNotFoundError:
        print("找不到 %s 檔案" % fn)
    else:
        wordList = data.split()  # 將文章轉成串列
        print(fn, " 文章的字數是 ", len(wordList))  # 列印文章字數

def word_operation():
    word = ''
    word = str(word)
    word = in_word()
    word_wr(word)
    word_rd()

def main():
    word_operation()

main()