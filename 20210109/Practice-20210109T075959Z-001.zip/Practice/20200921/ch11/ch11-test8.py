#ch11-test8
def pi(i):
    x = i
    result = 0
    count = 0
    for i in range(1,x+1):
        result += 4*((-1)**(i+1)/(2*i-1))
        if i == 1 and count == 0:
            count += 1
            print("當 i = %6d 時 PI = %.5f" % (i, result))
        elif i != 1 or count > 0:
            if i != 1 and i % 1000 == 1:
                print("當 i = %6d 時 PI = %.5f"%(i,result))
pi(9000)