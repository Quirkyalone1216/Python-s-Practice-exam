#ch11-test9
#判斷數值是否為正數
def isPositive(num):
    try:
        float(num)
    except:
        return False
    else:
        if float(num) <= 0:
            return False
        else:
            return True
#判斷直角三角形是否可以組成
def isRightTriangle(s1,s2,s3):
    if s1**2 + s2**2 == s3**2 or s1**2 + s3**2 == s2**2 or s2**2 + s3**2 == s1**2:
        return True
    else:
        return False
#判斷三角形是否可以組成
def isTriangle(s1,s2,s3):
    if s1+s2>s3 and s1+s3>s2 and s2+s3>s1:
        if s1==s2==s3:
            print('%.2f,%.2f,%.2f能組成等邊三角形'%(s1,s2,s3))
            Triangle_Area(s1, s2, s3)
        elif s1==s2 or s1==s3 or s2==s3:
            if isRightTriangle(s1,s2,s3):
                print('%.2f,%.2f,%.2f能組成等腰直角三角形'%(s1,s2,s3))
                Triangle_Area(s1, s2, s3)
            else:
                print('%.2f,%.2f,%.2f能組成等腰三角形'%(s1,s2,s3))
                Triangle_Area(s1, s2, s3)
        elif isRightTriangle(s1,s2,s3):
            print('%.2f,%.2f,%.2f能組成直角三角形'%(s1,s2,s3))
            Triangle_Area(s1, s2, s3)
        else:
            print('%.2f,%.2f,%.2f能組成普通三角形'%(s1,s2,s3))
            Triangle_Area(s1, s2, s3)
    else:
        print('%.2f,%.2f,%.2f不能組成三角形'%(s1,s2,s3))
#三角形面積計算
def Triangle_Area(s1,s2,s3):
     s = (s1+s2+s3) / 2                       #Half_perimeter
     area = (s*(s-s1)*(s-s2)*(s-s3))**0.5
     print("三角形面積為%.2f"%area)

#Main
a = input("請輸入第1個數字:")
while not isPositive(a):
    print("不是有效數字,請重新輸入:")
b = input("請輸入第2個數字:")
while not isPositive(b):
    print("不是有效數字,請重新輸入:")
c = input("請輸入第3個數字:")
while not isPositive(c):
    print("不是有效數字,請重新輸入:")
a = float(a)
b = float(b)
c = float(c)
isTriangle(a,b,c)
