#ch11-test1
def absoulte(n):
    result = abs(n)
    return result
keyboard = float(input("Input value :"))
print("Output value :",absoulte(keyboard))