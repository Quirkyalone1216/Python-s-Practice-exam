#ch11-test3
def Solution1_reverse(n):                                       #反轉串列法
    n = list(n)
    n.reverse()
    result = ''.join(n)
    return result
def Solution2_reverse(n):                                       #迴圈反向迭代法
    n= list(n)
    result = ''
    for i in n:
        result = i + result
    return result
def Solution3_reverse(n):                                       #反向迴圈迭代法
    n = list(n)
    result = ''
    for i in n[::-1]:
        result += i
    return result
def Solution4_reverse(n):                                       #倒序切片法
    result = n[::-1]
    return result
def Solution5_reverse(n):                                       #遍歷索引法
    list(n)
    result = ''
    for i in range(1,len(n)+1):
        result = result + n[-i]
    return result
def Solution6_reverse(n):                                       #串列彈出法
    n = list(n)
    result = ''
    while len(n) > 0:
        result = result + n.pop()
    return result
def Solution7_reverse(n):                                       #串列解析式法
    list(n)
    result = ''.join(i for i in n[::-1])
    return result
def Solution8_reverse(n):                                       #累積相加法
    list(n)
    from functools import reduce
    def f(x,y):
        return y+x
    result = reduce(f,n)
    return result
def Solution9_reverse(n):                                       #匿名函式法
    list(n)
    from functools import reduce
    result = reduce(lambda x,y:y+x,n)
    return result
def Solution10_reverse(n):                                      #串列倒序法
    n = list(n)
    n.sort(reverse=True)
    result = ''.join(n)
    return result
val = input("Input value :")
print("Value had been reverse :",Solution10_reverse(val))