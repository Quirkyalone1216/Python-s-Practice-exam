#ch11-test6
#Re-Design ch11_14.py
def guest_info(firstname, middlename, lastname, gender):
    """ 整合客戶名字資料 """
    if gender == "M":
        welcome = 'Mr.' + ' ' + lastname + ' ' + middlename +  ' ' + firstname +  ' ' + 'Welcome'
    else:
        welcome = 'Miss' +  ' ' + lastname + ' ' + middlename + ' ' + firstname +  ' ' + 'Welcome'
    return welcome

info1 = guest_info('Hung', 'Carl', 'Ivan', 'M')
info2 = guest_info('Hung', 'Ice', 'Mary', 'F')
print(info1)
print(info2)
