#ch11-test4
def MultipleFunction(n1,n2):
    add = n1 + n2
    sub = n1 - n2
    mul = n1 * n2
    div = n1 / n2
    return add,sub,mul,div
n1 = float(input("Value 1 :"))
n2 = float(input("Value 2 :"))
add,sub,mul,div = MultipleFunction(n1,n2)
print("Addition Result :",add)
print("Subtraction Result :",sub)
print("Multiplication Result :",mul)
print("Division Result :",div)