#ch11-test2
def mymax(n1,n2):
    max_n=max(n1,n2)
    return max_n
num1 = float(input("Input first compare value :"))
num2 = float(input("Input second compare value :"))
print("Larger value is :",mymax(num1,num2))