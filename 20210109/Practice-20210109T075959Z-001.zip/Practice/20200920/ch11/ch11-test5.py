#ch11-test5
#Expand ch11-test4 function
def Addition(n1,n2):
    return n1+n2
def Subtraction(n1,n2):
    return n1-n2
def Multiplication(n1,n2):
    return n1*n2
def Division(n1,n2):
    return n1/n2

while 1:
    n1 = float(input("Value 1 :"))
    n2 = float(input("Value 2 :"))
    operator = input("Please Input Operator(+,-,*,/) :")
    if operator == '+':
        print("Value1 + Value2 :",Addition(n1,n2))
    elif operator == '-':
        print("Value1 - Value2 :",Subtraction(n1,n2))
    elif operator == '*':
        print("Value1 * Value2 :",Multiplication(n1,n2))
    elif operator == '/':
        print("Value1 / Value2 :",Division(n1,n2))
    elif operator != ('+' and '-' and '*' and '/'):
        print("運算方法輸入錯誤")
    repeat = input("是否繼續(y/n)? 輸入非y字元可結束系統: ")
    if repeat != 'y':
        break
    elif repeat == 'y':
        continue