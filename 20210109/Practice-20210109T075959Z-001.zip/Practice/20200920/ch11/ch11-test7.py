#ch11-test7
def CtoF(c):
    f = c * (9/5) + 32
    return f
def FtoC(f):
    c = (f-32) * 5 / 9
    return c
degree = float(input("Please Input degree value :"))
print("Choose Transform Mode ",'\n',"Mode1:Fahrenheit Transform to Celsius ",'\n',"Mode2:Celsius Transform to Fahrenheit")
mode = input("Please choose Mode (1/2) :")
if mode == '1':
    print(round(FtoC(degree),2)," Celsius Degree")
elif mode == '2':
    print(round(CtoF(degree),2)," Fahrenheit Degree")
elif mode != ('1' and '2'):
    print("Mode Input Error")