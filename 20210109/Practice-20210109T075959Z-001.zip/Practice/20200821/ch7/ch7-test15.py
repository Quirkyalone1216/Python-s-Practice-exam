#ch7-test15
buyers = [['James',1030],
          ['Curry',893],
          ['Durant',2050],
          ['Jordan',990],
          ['David',2110],
          ['Kevin',15000],
          ['Mary',10050],
          ['Tom',8800]]
goldbuyers = []
vipbuyers = []
infinitebuyers = []
while buyers:
    index_buyer = buyers.pop()
    if index_buyer[1] >= 10000:
        infinitebuyers.append(index_buyer)
    elif index_buyer[1] >= 1000:
        vipbuyers.append(index_buyer)
    else:
        goldbuyers.append(index_buyer)
print("Infinite買家資料:",infinitebuyers)
print("VIP     買家資料:",vipbuyers)
print("Gold    買家資料:",goldbuyers)