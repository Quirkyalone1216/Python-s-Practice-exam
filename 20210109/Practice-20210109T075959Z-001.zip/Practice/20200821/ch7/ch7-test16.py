#ch7-test16
#最大公約數(輾轉相除法/歐幾里得算法)
a = int(input("第一個數字:"))
b = int(input("第二個數字:"))
c = 0
if a<b:
    c = a
    a = b
    b = c
while a%b != 0:
    c = a % b
    a = b
    b = c
print("最大公約數為%d"%b)