#ch7-test17
fruits = ['李子','香蕉','頻果','西瓜','桃子']
for count,fruit in enumerate(fruits,1):
    print(count,fruit)