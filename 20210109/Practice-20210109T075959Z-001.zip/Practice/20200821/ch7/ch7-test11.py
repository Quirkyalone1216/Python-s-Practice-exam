#ch7-test11
#直角三角形 數字階層
rows = 9
for i in range(2,rows+1):
    for j in range(1,i+1):
        print(j,end="")
    print()