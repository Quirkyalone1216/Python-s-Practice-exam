#ch7-test8
from itertools import permutations
print(list(permutations("12345",2)))
