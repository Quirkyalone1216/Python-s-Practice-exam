#ch7-test14
answer = 30
guess = 0
guess_count = 1
while guess != answer:
    guess = int(input("請猜1-100的數字:"))
    if guess > answer:
        print("請猜小一點")
        guess_count += 1
    elif guess < answer:
        print("請猜大一點")
        guess_count += 1
    else:
        print("恭喜猜對了")
        print("所猜次數為%d"%guess_count)