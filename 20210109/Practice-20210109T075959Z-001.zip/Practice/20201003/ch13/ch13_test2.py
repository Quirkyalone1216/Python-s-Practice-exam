#ch13_test2
from ch13 import Arithmetic
def choose():
    val = int(input('請輸入運算\n'
                '1:加法\n'
                '2:減法\n'
                '3:乘法\n'
                '4:除法\n'
                '輸入1/2/3/4:'))
    if not val:
        print('輸入錯誤')
        val = int(input('請輸入運算\n'
                    '1:加法\n'
                    '2:減法\n'
                    '3:乘法\n'
                    '4:除法\n'
                    '輸入1/2/3/4:'))
    return val
def calcaulate(val):
    op1 = input('Op1=')
    if not (op1 or int,float(op1)):
        print('輸入錯誤')
        op1 = input('Op1=')
    op2 = input('Op2=')
    if not op2:
        print('輸入錯誤')
        op2 = input('Op2=')
    op1 = float(op1)
    op2 = float(op2)
    if val == 1:
        print(Arithmetic.add(op1, op2))
    elif val == 2:
        print(Arithmetic.sub(op1, op2))
    elif val == 3:
        print(Arithmetic.mul(op1, op2))
    elif val == 4:
        print(Arithmetic.div(op1, op2))
def main():
    calcaulate(choose())
main()