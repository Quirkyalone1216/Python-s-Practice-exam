#ch13_test1
import ch13.makefood
ch13.makefood.make_noodle('牛肉麵','酸菜','豆瓣醬','蔥花')
ch13.makefood.make_noodle('肉絲麵','香菜','豆芽')