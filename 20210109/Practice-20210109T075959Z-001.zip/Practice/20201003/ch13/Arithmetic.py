#Arithmetic.py
def add(op1,op2):
    return op1+op2
def sub(op1,op2):
    return op1-op2
def mul(op1,op2):
    return op1*op2
def div(op1,op2):
    return op1/op2