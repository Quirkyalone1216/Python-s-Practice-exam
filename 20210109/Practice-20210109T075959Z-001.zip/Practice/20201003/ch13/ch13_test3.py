#ch13_test3
#Re-Design ch13_15.py
import random  # 導入模組random

min, max = 0, 30
count = 0
yourNum = int(input("請猜0-30之間數字: "))
if not yourNum:
    print('輸入錯誤')
    yourNum = int(input("請猜0-30之間數字: "))
while 1:
    if count > 0:
        yourNum = input("請猜0-30之間數字(Q或q則程式結束): ")
        if not yourNum:
            print('輸入錯誤')
            yourNum = input("請猜0-30之間數字(Q或q則程式結束): ")
        if yourNum == 'Q' or yourNum == 'q':  # 若輸入Q或q
            break  # 程式結束
        else:
            yourNum = int(yourNum)
    generate_ans = 0
    if generate_ans == 0:
        ans = random.randint(min, max)  # 隨機數產生答案
        generate_ans += 1
    if yourNum == ans:
        print("恭喜!答對了")
        break
    else:
        if count == 0:
            count += 1
        else:
            if yourNum < ans:
                print("請猜大一些")
            elif yourNum > ans:
                print("請猜小一些")
