import qrcode
from PIL import Image
import os
import glob
import send2trash
import time


def ProcessTime():
    # 開始測量
    start = time.process_time()
    # 要測量的程式碼
    for i in range(10000):
        "-".join(str(n) for n in range(100))
    # 結束測量
    end = time.process_time()
    # 輸出結果
    print("執行時間：%f 秒" % (end - start))


def GetCurrentPath():
    """讀取當前檔案路徑和Resoures資料夾內的檔案名稱"""
    for DirPath, SubDirNames, FileNames in os.walk(os.getcwd()):
        ObjDir = os.path.join(DirPath, 'Resoures')
        Files = os.listdir(ObjDir)
        return ObjDir, Files


def check_file_extension(datas):
    """確認檔案副檔名"""
    result_img = []
    for data in datas:
        if data.lower().endswith(('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
            if data is not None:
                result_img.append(data)
    return result_img


def file_process():
    obj_dir, files = GetCurrentPath()
    outdir_path = os.path.join(obj_dir, 'Output')
    dir_exists = os.path.exists(outdir_path)
    if dir_exists is False:
        os.mkdir(outdir_path)
    elif dir_exists is True:
        list_files = []
        list_files1 = []
        for file1 in os.listdir(outdir_path):
            list_files1.append(file1)
            for file in glob.glob('fig17_7.*'):
                list_files.append(file)
        if len(list_files) > 0:
            for file_exist in list_files:
                send2trash.send2trash(file_exist)
        elif len(list_files) == 0:
            return obj_dir, outdir_path


def ResizeImage(filein, outdir_path):
    """重新設計圖像,並輸出於Output資料夾"""
    qr = qrcode.QRCode(version=6,
                       error_correction=qrcode.constants.ERROR_CORRECT_H,
                       box_size=10,
                       border=4)
    qr.add_data('https://www.oit.edu.tw/')
    img = qr.make_image(fill_color='Green')
    width, height = img.size
    with Image.open(filein) as obj:
        obj_width, obj_height = obj.size
        img.paste(obj, (int((width-obj_width)//2), int((height-obj_height)//2)))
    img.save(os.path.join(outdir_path, "fig17_7.jpg"))


def img_process():
    """圖像處理"""
    obj_dir, outdir_path = file_process()
    result_file = os.listdir(obj_dir)
    result_img = check_file_extension(result_file)
    ObjIndex = result_img.index('school_mark.jpg')
    file_path = os.path.join(obj_dir, result_img[ObjIndex])
    ResizeImage(file_path, outdir_path)


if __name__ == '__main__':
    img_process()
    ProcessTime()
