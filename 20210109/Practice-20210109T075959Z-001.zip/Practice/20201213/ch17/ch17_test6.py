from PIL import Image, ImageDraw, ImageFont
import os
import send2trash
import glob
import time


def ProcessTime():
    # 開始測量
    start = time.process_time()
    # 要測量的程式碼
    for i in range(10000):
        "-".join(str(n) for n in range(100))
    # 結束測量
    end = time.process_time()
    # 輸出結果
    print("執行時間：%f 秒" % (end - start))


def GetCurrentPath():
    """讀取當前檔案路徑和Resoures資料夾內的檔案名稱"""
    for DirPath, SubDirNames, FileNames in os.walk(os.getcwd()):
        ObjDir = os.path.join(DirPath, 'Resoures')
        Files = os.listdir(ObjDir)
        return ObjDir, Files


def check_file_extension(datas):
    """確認檔案副檔名"""
    result_img = []
    for data in datas:
        if data.lower().endswith(('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
            if data is not None:
                result_img.append(data)
    return result_img


def GetFont():
    path = r"C:\Windows\Fonts"
    PathFiles = os.listdir(path)
    FontFiles = []
    for file in PathFiles:
        if file.lower().endswith(('.ttf', '.ttc', '.otf', '.otc')):
            if file is not None:
                FontFiles.append(file)
    ObjIndex = FontFiles.index(str('simsun.ttc'))
    FilePath = os.path.join(path, FontFiles[ObjIndex])
    return FilePath


def file_process():
    obj_dir, files = GetCurrentPath()
    outdir_path = os.path.join(obj_dir, 'Output')
    dir_exists = os.path.exists(outdir_path)
    if dir_exists is False:
        os.mkdir(outdir_path)
    elif dir_exists is True:
        list_files = []
        list_files1 = []
        for file1 in os.listdir(outdir_path):
            list_files1.append(file1)
            for file in glob.glob('fig17_6.*'):
                list_files.append(file)
        if len(list_files) > 0:
            for file_exist in list_files:
                send2trash.send2trash(file_exist)
        elif len(list_files) == 0:
            return obj_dir, outdir_path


def ResizeImage(filein, outdir_path):
    """重新設計圖像,並輸出於Output資料夾"""
    img = Image.open(filein)
    CopyImage = img.copy()
    CropImage = CopyImage.crop((66, 116, 172, 211))
    NewSize = (350, 500)
    newImage = CropImage.resize(NewSize)
    BaseImage = Image.new("RGB", (350+50+50, 500+50+200), "Green")
    BaseImage.paste(newImage, (50, 50))
    FontPath = GetFont()
    DrawObj = ImageDraw.Draw(BaseImage)
    strText = '你的名字'
    FontInfo = ImageFont.truetype(FontPath, 50)
    DrawObj.text((int((350-100)/2), int(500+(200/2))), strText, fill='Yellow', font=FontInfo)
    BaseImage.save(os.path.join(outdir_path, "fig17_6.jpg"))


def img_process():
    """圖像處理"""
    obj_dir, outdir_path = file_process()
    result_file = os.listdir(obj_dir)
    result_img = check_file_extension(result_file)
    for file in result_img:
        file_path = os.path.join(obj_dir, file)
        ResizeImage(file_path, outdir_path)


if __name__ == '__main__':
    img_process()
    ProcessTime()
