#ch6-test2
cars = ['Toyota','Nissan','Honda']
print("舊汽車銷售品牌",cars)
cars[1] = 'Ford'
print("薪汽車銷售品牌",cars)
