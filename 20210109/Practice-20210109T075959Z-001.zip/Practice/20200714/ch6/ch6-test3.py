#ch6-test3
str1 = ' Python '
str2 = 'is '
str3 = ' easy'
print(str1.strip(),str2.rstrip(),str3.lstrip())