#ch6-test1
test_achievement = [87,99,69,52,78,98,80,92]
element = len(test_achievement)
min = min(test_achievement)
max = max(test_achievement)
sum = sum(test_achievement)
avg = float(sum) / element
print("最高分為%d" %max)
print("最低分為%d" %min)
print("總分為%d" %sum)
print("平均為%.3f" %avg)

