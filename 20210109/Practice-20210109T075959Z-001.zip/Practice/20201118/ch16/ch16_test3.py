#ch16_test3
#Re_Design ch16_20.py
import re

def searchStr(pattern, msg):
    txt = re.search(pattern, msg)
    if txt == None:  # 搜尋失敗
        print("搜尋失敗 ", txt)
    else:  # 搜尋成功
        print("搜尋成功 ", txt.group())
def pattern_choice():
    msg1 = 'son'
    msg2 = 'sonson'
    msg3 = 'sonsonson'
    msg4 = 'sonsonsonson'
    msg5 = 'sonsonsonsonson'
    pattern_a = '(son){2,}'
    pattern_b = '(son){,5}'
    i = 0
    while i < 3:
        if i == 1:
            print("pattern條件:重複2次son~無限次",'\n','---------------')
            searchStr(pattern_a, msg1)
            searchStr(pattern_a, msg2)
            searchStr(pattern_a, msg3)
            searchStr(pattern_a, msg4)
            searchStr(pattern_a, msg5)
            print('---------------','\n')
        elif i == 2:
            print("pattern條件:1次son~5次son", '\n', '---------------')
            searchStr(pattern_b, msg1)
            searchStr(pattern_b, msg2)
            searchStr(pattern_b, msg3)
            searchStr(pattern_b, msg4)
            searchStr(pattern_b, msg5)
            print('---------------','\n')
        i += 1
if __name__ == '__main__':
    pattern_choice()