#ch11-test16
score_list = [25,18,12,22,31,17,26,19,18,10]
score_over_20 = list(filter(lambda x:x>=20,score_list))
print('得分超過20分(含)的串列:',sorted(score_over_20))