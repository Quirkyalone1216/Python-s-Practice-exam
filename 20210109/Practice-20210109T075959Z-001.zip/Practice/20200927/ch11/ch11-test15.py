#ch11-test15
mylist = [5, 10, 15, 20, 25, 30]

Evenlist = list(filter(lambda x: (x % 2 == 0), mylist))

# 輸出偶數串列
print("偶數串列: ",Evenlist)
