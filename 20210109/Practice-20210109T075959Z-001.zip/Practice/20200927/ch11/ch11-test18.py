#ch11-test18
mylist = [1,2,3,4,5]
print(list(map(str,mylist)))