#ch11-test13
def fib(n):
    if n == 0:
        return 0
    elif n <= 2:
        return 1
    else:
        return fib(n-1)+fib(n-2)
def fib_solution2(n):
    a,b=1,1
    while a<n:
        print(a)
        print(b)
        a = a + b
        b = a + b

n = input('Please input value:')
if not n:
    print('Your input value is None.')
    n = input('Please input value again:')
n = int(n)
for i in range(0,n):
    fib(i)
    print(f'F{i}=',fib(i))
xlist = [fib(x) for x in range(n)]
print(xlist)
