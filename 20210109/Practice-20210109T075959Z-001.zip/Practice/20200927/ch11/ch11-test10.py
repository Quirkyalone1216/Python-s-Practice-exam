#ch11-test10
def isPalindrome(n):
    s1 = len(s)
    i = 0
    count = 1
    while i <= (s1/2):
        if s[i] == s[s1-i-1]:
            count = 1
            i += 1
        else:
            count = 0
            break
    if count == 1:
        print('輸入數值為回文')
    else:
        print('輸入數值不是回文')
s = input('請輸入一個數值:')
if not s:
    print('輸入為空數值')
    s = input('請重新輸入一個數值；')
isPalindrome(s)