#ch11-test11                    #Re-Design ch11_24.py
def make_pizza(pizza_size, *toppings):
    """ 列出製作披薩的配料 """
    print("這個 ", pizza_size,"吋", " 披薩所加配料如下")
    for topping in toppings:
        print("--- ", topping)
make_pizza('5','總匯')
make_pizza('8','蔬菜','辛香料','起司','蘑菇','海鮮')