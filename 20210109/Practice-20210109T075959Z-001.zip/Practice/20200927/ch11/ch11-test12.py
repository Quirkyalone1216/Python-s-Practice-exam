#ch11-test12
def isPalindrome(s):
    s1 = len(s)
    i = 0
    count = 1
    while i <= (s1/2):
        if s[i] == s[s1-i-1]:
            count = 1
            i += 1
        else:
            count = 0
            break
    if count == 1:
        print('輸入字串為回文')
    else:
        print('輸入字串不是回文')
s = input('請輸入一個字串:')
if not s:
    print('輸入為空字串')
    s = input('請重新輸入一個字串:')
isPalindrome(s)